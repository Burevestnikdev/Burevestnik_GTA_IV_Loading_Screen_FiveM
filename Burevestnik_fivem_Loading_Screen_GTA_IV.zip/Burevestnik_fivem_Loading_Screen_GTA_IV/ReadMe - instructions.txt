██████╗░██╗░░░██╗██████╗░███████╗██╗░░░██╗███████╗░██████╗████████╗███╗░░██╗██╗██╗░░██╗
██╔══██╗██║░░░██║██╔══██╗██╔════╝██║░░░██║██╔════╝██╔════╝╚══██╔══╝████╗░██║██║██║░██╔╝
██████╦╝██║░░░██║██████╔╝█████╗░░╚██╗░██╔╝█████╗░░╚█████╗░░░░██║░░░██╔██╗██║██║█████═╝░
██╔══██╗██║░░░██║██╔══██╗██╔══╝░░░╚████╔╝░██╔══╝░░░╚═══██╗░░░██║░░░██║╚████║██║██╔═██╗░
██████╦╝╚██████╔╝██║░░██║███████╗░░╚██╔╝░░███████╗██████╔╝░░░██║░░░██║░╚███║██║██║░╚██╗
╚═════╝░░╚═════╝░╚═╝░░╚═╝╚══════╝░░░╚═╝░░░╚══════╝╚═════╝░░░░╚═╝░░░╚═╝░░╚══╝╚═╝╚═╝░░╚═╝

Hello, I am grateful to you that you bought my resource: GTA IV Loading Screen!

In order to install the resource, you would need to complete a few simple steps:

1) Move the folder with the Loading Screen to the folder where you have the rest of the FiveM server resources.
2) Write the line (unsure Burevestnik_fivem_Loading_Screen_GTA_IV) to your server.cfg
3) Enjoy the new loading screen!

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
If you have any technical questions or need support, then don't be afraid to contact me at Discord. (Burevestnik#4495)
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
If you want to change the music, then put your file with the .mp3 extension, then go to the file (Index.html ) find line 44 and change the file name if it differs from the original one.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
If you want to change the text, then go to the file (Index.html ) find line 40 and change the text to the desired one.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
To play music, press the space bar. If you want to change the music start key, go to the file (Index.html ) find line 55, and change the numbers 33 to the desired ones (The site where you can find the key number: https://theasciicode.com.ar/)
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
If you want to add more slides, then you need to follow the examples in the files (Index.html & style.css & app.js)