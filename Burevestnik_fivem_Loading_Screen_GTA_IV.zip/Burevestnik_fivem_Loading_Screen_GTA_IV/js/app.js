// ██████╗░██╗░░░██╗██████╗░███████╗██╗░░░██╗███████╗░██████╗████████╗███╗░░██╗██╗██╗░░██╗
// ██╔══██╗██║░░░██║██╔══██╗██╔════╝██║░░░██║██╔════╝██╔════╝╚══██╔══╝████╗░██║██║██║░██╔╝
// ██████╦╝██║░░░██║██████╔╝█████╗░░╚██╗░██╔╝█████╗░░╚█████╗░░░░██║░░░██╔██╗██║██║█████═╝░
// ██╔══██╗██║░░░██║██╔══██╗██╔══╝░░░╚████╔╝░██╔══╝░░░╚═══██╗░░░██║░░░██║╚████║██║██╔═██╗░
// ██████╦╝╚██████╔╝██║░░██║███████╗░░╚██╔╝░░███████╗██████╔╝░░░██║░░░██║░╚███║██║██║░╚██╗
// ╚═════╝░░╚═════╝░╚═╝░░╚═╝╚══════╝░░░╚═╝░░░╚══════╝╚═════╝░░░░╚═╝░░░╚═╝░░╚══╝╚═╝╚═╝░░╚═╝

$(document).ready(function(){

  $("#container").fadeIn(200);

  $("#roman").delay(200).fadeIn(300).animate({
    bottom:'-40', left:'27%'
    }, 5000, 'linear').fadeOut(300);
    $("#roman_bg").delay(200).fadeIn(300).animate({
      bottom:'-40', left:'27%'
      }, 5000, 'linear').fadeOut(300);

  $("#nico").delay(5500).fadeIn(200).animate({
    bottom:'-30', left:'57%'
  }, 5000, 'linear').fadeOut(300);
  $("#nico_bg").delay(5500).fadeIn(300).animate({
      bottom:'-30', left:'57%'
    }, 5000, 'linear').fadeOut(300);
  
  
  $("#dmitriy").delay(10900).fadeIn(300).animate({
    bottom:'-80', left:'43%'
    }, 5000, 'linear').fadeOut(300);
    $("#dmitriy_bg").delay(10900).fadeIn(300).animate({
      bottom:'-80', left:'43%'
      }, 5000, 'linear').fadeOut(300);

  $("#vlad").delay(16100).fadeIn(300).animate({
    bottom:'-40', left:'27%'
    }, 5000, 'linear').fadeOut(300);
    $("#vlad_bg").delay(16100).fadeIn(300).animate({
      bottom:'-40', left:'27%'
      }, 5000, 'linear').fadeOut(300);    
            
  $("#bad").delay(21400).fadeIn(300).animate({
    bottom:'-30', left:'57%'
      }, 5000, 'linear').fadeOut(300);
      $("#bad_bg").delay(21400).fadeIn(300).animate({
        bottom:'-30', left:'57%'
        }, 5000, 'linear').fadeOut(300); 

  $("#ray").delay(26700).fadeIn(300).animate({
    bottom:'-80', left:'43%'
    }, 5000, 'linear').fadeOut(300);
    $("#ray_bg").delay(26700).fadeIn(300).animate({
      bottom:'-80', left:'43%'
      }, 5000, 'linear').fadeOut(300);

  $("#x").delay(32000).fadeIn(300).animate({
    bottom:'-40', left:'27%'
    }, 5000, 'linear').fadeOut(300);
    $("#x_bg").delay(32000).fadeIn(300).animate({
      bottom:'-40', left:'27%'
      }, 5000, 'linear').fadeOut(300);    

  $("#end_bg").delay(37300).fadeIn(300).fadeOut(600000);
  $("#logo").delay(37300).fadeIn(300).fadeOut(600000);
});